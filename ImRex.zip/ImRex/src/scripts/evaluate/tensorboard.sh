#!/bin/bash

. env/bin/activate

tensorboard --logdir output/logs

