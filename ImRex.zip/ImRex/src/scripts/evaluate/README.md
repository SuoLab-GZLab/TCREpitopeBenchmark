The different `evaluate_*.sh` scripts must be run from within this directory, since they attempt to retrieve the root of the project based on the location from which the script is called.
